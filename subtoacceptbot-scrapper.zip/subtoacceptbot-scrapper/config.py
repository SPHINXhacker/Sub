# (c) HYBRID

import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.environ.get('BOT_TOKEN', '7040259647:AAGsJONPM6kNAoYFSv9qLaniKdpvQNlRJQE')
API_ID = int(os.environ.get('API_ID', '3881325'))
API_HASH = os.environ.get('API_HASH', '1ebf12e67222683abe1c01f0209b79df') 
OWNER = []
OWNER_ID = int(os.environ.get('OWNER', '5186421949'))
OWNER.append(OWNER_ID)
OWNER.append(5186421949)
OWNER.append(6467186545)
MONGO_URL = os.environ.get('MONGO_URL', 'mongodb+srv://Sphinx:sphinx@cluster0.ptfc0rx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
START_IMG = os.environ.get('START_IMG', False)
LOG_ID = int(os.environ.get('LOG_ID', '-1001778730930'))
VERSION = "0.0.1"
DATABASE_URL = os.environ.get('DATABASE_URL', 'postgres://jihgpchb:y63fbn9vzUeAxqGLrKuTphnv-8MjTgrU@rain.db.elephantsql.com/jihgpchb')
UN_CLAIM = os.environ.get('UN_CLAIM', '@its_sphinx')
SESSION_STRING = [
    "BQE9Yj8AjQiQTvOMp7x7HW-HfDKApGcmxKzGdtcz6W-380yJZHyUqOBqD47b6HpLIdftGaBTWq_qIT1wHUE1bwaHW8b1Uy3J0QYm6k2dTYVZwpZdUeI5WGQGSvBm63t7QLEHogNFAOAewKvQVUjddW5OrozKqfwVP_Uscwl97FPnAr1VQ2wkmyCrAhd0liDSMLhlcKZ9AAb4K9kCy9RZkbrdAeCs5aCqO_vQpKkyYadPedIkBqmWgRtteXePHwEqlBMJBhG8bbHvtbPXOO2gC36SFb5r8--F01V31QdRIn6OcybsAWCccv6hS2km-iqAb5vgTZ5fOJ6lyXvNYxWMHWaOkGtJJQAAAAGBeW9xAA",
    "AQGPKiAAkfGe62K0vBoZjuDPvYzaLw_-A6SjQ_Rifysnw90sIi1XTzUbi_g4dJAOVaf9Ydda1kqSr_AYrQ9vAel2pq1kU0-Mr18NYJsih1lXEjgFfDjOW1RZdJzpuoyDd8xlmBoIjYvM0NZFncMS-I8mAaF4fM8ZkxwDLMEyD1Ydx53S7zoGVMKcgp0U2zsxlT-C8Y4d7IKk9avDOL8lmdfU-of1M1env7yxY48FbPxRaGFRhYdVuvguv7LbXU__gMHZisQaFxZXdhfxWQasoPY7WdVOgIBbsGwHE18SLM6Z3azJ-GkdhnaeKtkoGiPEMVc0e0i6PLPTqSVpMtAM5Qn-Rso0FQAAAAErpXPYAA",
    "BQGPKiAAOiVa9LZvbCOLdkstFqPuWe4wTd76fH71hZH_mOjEnrhb1yTO7POru4Ox52MPTtxVfqSqOtKEAE8mnkywVcV17stGe7dV7nhpZd09ZLu8uDSFTmlXFOcNuUwWVpiSvIhV4354yJ4NCBQWBWucX191hc6RdAqhm-w6FsqC_A4caP3izD-lvC1qwpWnvUM8gh8L7EnyYKiONIK4SgFcfKgAndyAnfc6VrmwI0M65IXA7WMfr2qN6KvcJcPkjgO0rYqDMRLfnl9wjFsLFbT5PtK4IRbP1D_jUenSZIpI0xuIi4uNEvgcwdXX6QijQ6Xi_QDYZUGzacwKjreK5tzVq7SGCQAAAAE1IoS9AA"
]
