# (c) HYBRID
import os
import asyncio
import datetime
import time

from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup

from hybrid import app, RUNNING, OWNER
from hybrid.plugins.error import capture_err

@app.on_message(filters.command("cancel") & filters.user(OWNER))
@capture_err
async def cancel_process(_, message):
    msg = await message.reply_text("⏳")
    if RUNNING:
        RUNNING.clear()
        await msg.edit("✅ **Process list cancelled**")
        return
    else:
        await msg.edit("⚠️ **No process running currently**")
        return

@app.on_message(filters.command("start") & filters.user(OWNER))
@capture_err
async def cancel_process(_, message):
    msg = await message.reply_text("⏳")
    await msg.edit("**I'm Working...**")
