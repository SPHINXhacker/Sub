# (c) HYBRID

class temp(object):
    RUNNING = []

